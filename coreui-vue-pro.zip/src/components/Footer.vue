<template>
  <footer class="app-footer">
    <span><a href="http://coreui.io/pro/">CoreUI Pro</a> &copy; 2018 creativeLabs.</span>
    <span class="ml-auto">Powered by <a href="http://coreui.io/pro/">CoreUI Pro</a></span>
  </footer>
</template>
<script>
export default {
  name: 'c-footer'
}
</script>
